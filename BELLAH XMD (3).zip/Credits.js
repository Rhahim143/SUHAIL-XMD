// Kalo mau Ambil Code Atau recode Boleh aja Tapi izin dulu 


/* Reupload Atau Review Bot 
 * 1. Tag @YASSxOFC & @Ziyo232
 * 2. Tambahkan Saya ke Credits Kalo bisa
 *\
 
/* Thanks To
> Xeon ( Base / Creator )
> YASSxOFC ( Recode )
> Always Ziyoo ( Add Fitur / Recode )
> Always Kyuu ( KyuuDev / Add Fitur )
> Subscriber ( Supporter )
> Whiskeysockets ( Baileys )
> All Creator Bot Whatsapp ( Creator / kang recode )
> 1 orang ga di kenal ( Tester )
> Jarz ( Temen / Recode Bug )

